import React, { useState } from "react";
import logo from './logo.svg';
import './App.css';

function App() {
  const [result, setResult] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8000/main.php", {
        method: "POST",
        body: new FormData(e.target)
      });
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
      <form method="post" id="form" onSubmit={handleSubmit}>
        <input type="submit" value="Get feed"/>
      </form>
      <div className="result">
        {result.map((item, index) => (
          
          <div key={index}>
            <div>{item}</div>
            <p>Username: {item.username}</p>
            <p>Timestamp: {item.timestamp}</p>
            <p>Media Type: {item.media_type}</p>
            <img src={item.media_url} alt={`Media ${index}`} />
            <p>Permalink: <a href={item.permalink} target="_blank" rel="noopener noreferrer">{item.permalink}</a></p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
