<?php
/*
Plugin Name: Get Instagram Post
Description: This plugin will add a Post from Instagram
Author: Shivangi Maheshvari
Version: 0.0.1
*/
header("Access-Control-Allow-Origin: http://localhost:3000");

class InstagramFeed {
    public function getFeed() {
        // Get feed based on token generated in developer account
        // Query the user media
        $fields = "id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username";
        $token = "IGQWRNWG1KQkRNMUc3NnlGVm03R3ZAGUGU1OGZAjUmh4RXVXRE9UUnlPb095eHRCQjZAfZA3VQb0JVTTg0NURROW5SS2pGX0t2OVdyV2oyckVlc1duUU1sd0xjeVItcm1fcUMyWkxZAU3I3VnMyTElzVVkyVVlmNVNJakUZD";
        $limit = 10;
         
        $json_feed_url = "https://graph.instagram.com/me/media?fields={$fields}&access_token={$token}&limit={$limit}";
        $json_feed = @file_get_contents($json_feed_url);
        $contents = json_decode($json_feed, true, 512, JSON_BIGINT_AS_STRING);
        return $contents;
    }
}

// Create an instance of the InstagramFeed class
$instagramFeed = new InstagramFeed();

// Get the feed data
$feedData = $instagramFeed->getFeed();

// Output the feed data as JSON
header('Content-Type: application/json');
echo json_encode($feedData);
?>