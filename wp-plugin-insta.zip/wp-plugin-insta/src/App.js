import React, { useState } from "react";
import $ from "jquery";
import logo from './logo.svg';
import './App.css';

function App() {
  const [name,setName] = useState("");
  const [result,setResult] = useState("");

  const handleChange = (e) => {
    setName(e.target.value);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const form = $(e.target);
    $.ajax({
        type: "POST",
        url: form.attr("action"),
        data: form.serialize(),
        success(data) {
            setResult(data);
        },
    });
};

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      
      </header>
      <form method="post" id="form" action="http://localhost:8000/main.php" onSubmit={(event) => handleSubmit(event)}>
      <label>Enter your instgram id:
      <input 
        type="text" 
        name="instaid" 
        id="instaid"
        value={name}
        onChange={(event) => handleChange(event)}
      />
      </label>
      <br></br>
        <input type="submit" />
    </form>
    {result}
    </div>
  );
}

export default App;
