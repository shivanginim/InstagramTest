<?php
/*
Plugin Name: Get Instagram Post
Description: This plugin will add a Post from Instagram
Author: Shivangi Maheshvari
Version: 0.0.1
*/
header("Access-Control-Allow-Origin: http://localhost:3000");

require_once "instagramFeed.php";

// Don't access this file directly
defined('ABSPATH') or die();

/* Instagram App */

$instagramFeed = new InstagramFeed();

print($instagramFeed->getFeed());
?>