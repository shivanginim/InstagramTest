<?php

class InstagramFeed {

    public function request($path) {
        return json_decode(file_get_contents($path), true); 
    }

    public function getToken() {
        $client_id = '907892867688269';

        /* Instagram App Client Secret */
        $client_secret = 'bc051c9856806d2fabccb14d4ce2d329';

        $redirect_uri = 'http://localhost:3000';

		$url = 'https://api.instagram.com/oauth/access_token';
		
		$urlPost = 'client_id='. $client_id . '&redirect_uri=' . $redirect_uri . '&client_secret=' . $client_secret . '&code='. $code . '&grant_type=authorization_code';
		$ch = curl_init();		
		curl_setopt($ch, CURLOPT_URL, $url);		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $urlPost);			
		$data = json_decode(curl_exec($ch), true);	
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);	
		curl_close($ch); 		
		if($http_code != '200')			
			throw new Exception('Error : Failed to receive access token');
		
		return $data['access_token'];	
	}

    public function refreshToken() {
        $path = $this->getPath();
        $filename = $this->getFilename();
        $date = date("Y-m-d H:i:s");
        $array = ["updated" => $date];

        if (!file_exists($path)) {
            mkdir($path, 0777, true);
            $fp = fopen("$path/$filename", "w");
            fwrite($fp, json_encode($array));
            fclose($fp);
        }
        
        $date_json = $this->request("$path/$filename")["updated"];

        if (strtotime($date) - strtotime($date_json) > 86400) {
            $this->request("https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=" . $this->getToken());
            $array = ["updated" => $date];
            $fp = fopen("$path/$filename", "w");
            fwrite($fp, json_encode($array));
            fclose($fp);
        }
        
    }

    public function getFeed($fields = null) {
        $fields = $fields ?? 'username,permalink,timestamp,caption';
        $this->refreshToken();
        return $this->request("https://graph.instagram.com/me/media?fields=" . $fields . "&access_token=" . $this->getToken())["data"];
    }
}
?>